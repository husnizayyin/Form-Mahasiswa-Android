<?php 
	$ip = "http://http://192.168.43.80/prj_uas/";
	$koneksi = new Mysqli("localhost","root","","db_data")or die (Mysqli_errno());
 ?>